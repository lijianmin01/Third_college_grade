#include<stdio.h>

int main(){
    double PI = 3.141590;
    printf("%lf",PI);
    return 0;
}